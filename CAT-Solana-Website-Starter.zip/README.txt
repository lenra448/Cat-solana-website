CAT / SOL website starter
1. Open index.html and edit the X and Telegram links.
2. Replace the contract address placeholder with your real official Solana token address.
3. Upload index.html to the root of your GitHub repository.
4. In GitHub, open Settings > Pages, choose Deploy from a branch, select main and /(root), then Save.
5. Wait for GitHub Pages to publish the website.

Important: The X and Telegram links currently point to generic home pages. Replace them with your real community links before publishing. The token address is intentionally a placeholder.
